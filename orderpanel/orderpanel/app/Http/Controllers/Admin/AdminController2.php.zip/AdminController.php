<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class AdminController extends Controller
{
    public function index()
    {
                $new = DB::table('orders')->where('status', 1)->count();
                $pendingPayment = DB::table('orders')->where('status', 2)->count();
                $pending = DB::table('orders')->where('status', 3)->count();
                $courier = DB::table('orders')->where('status', 4)->count();
                $invoice = DB::table('orders')->where('status', 5)->count();
                $pendingInvoice = DB::table('orders')->where('status', 6)->count();
                $delivered = DB::table('orders')->where('status', 7)->count();
                $booking = DB::table('orders')->where('status', 8)->count();
                $return = DB::table('orders')->where('status', 9)->count();
                $cancelled = DB::table('orders')->where('status', 10)->count();
        return view('admin.include.main', compact('new','pendingPayment','pending','courier','invoice','pendingInvoice','delivered','booking','return','cancelled'));
    }
}
